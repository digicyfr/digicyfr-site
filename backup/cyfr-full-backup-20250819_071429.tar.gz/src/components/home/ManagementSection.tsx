'use client';
import { CheckCircle, Monitor, BarChart3, Users, Zap } from 'lucide-react';
import { useTranslations } from 'next-intl';
import '@/styles/components/management-section.css';

export default function ManagementSection() {
  const t = useTranslations('management');

  const features = [
    {
      icon: <Monitor className="feature-icon" />,
      title: t('features.dashboard.title'),
      description: t('features.dashboard.description')
    },
    {
      icon: <BarChart3 className="feature-icon" />,
      title: t('features.analytics.title'),
      description: t('features.analytics.description')
    },
    {
      icon: <Users className="feature-icon" />,
      title: t('features.customers.title'),
      description: t('features.customers.description')
    },
    {
      icon: <Zap className="feature-icon" />,
      title: t('features.automation.title'),
      description: t('features.automation.description')
    }
  ];

  const benefits = [
    t('benefits.0'),
    t('benefits.1'),
    t('benefits.2'),
    t('benefits.3'),
    t('benefits.4'),
    t('benefits.5')
  ];

  return (
    <section id="management" className="management-section">
      <div className="container">
        <div className="section-header">
          <h2 className="section-title">{t('title')}</h2>
          <p className="section-subtitle">
            {t('subtitle')}
          </p>
        </div>

        <div className="management-content">
          <div className="features-grid">
            {features.map((feature, index) => (
              <div key={index} className="feature-card">
                <div className="feature-icon-wrapper">
                  {feature.icon}
                </div>
                <h3 className="feature-title">{feature.title}</h3>
                <p className="feature-description">{feature.description}</p>
              </div>
            ))}
          </div>

          <div className="benefits-section">
            <div className="benefits-header">
              <h3 className="benefits-title">{t('benefitsTitle')}</h3>
            </div>
            <div className="benefits-grid">
              {benefits.map((benefit, index) => (
                <div key={index} className="benefit-item">
                  <CheckCircle className="benefit-icon" />
                  <span className="benefit-text">{benefit}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="cta-section">
            <button className="cta-button primary">
              {t('cta.primary')}
            </button>
            <button className="cta-button secondary">
              {t('cta.secondary')}
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}