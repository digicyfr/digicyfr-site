'use client';
import { Search, Globe, Smartphone, ShoppingCart, CheckCircle } from 'lucide-react';
import { useTranslations } from 'next-intl';
import '@/styles/components/services-section.css';

export default function ServicesSection() {
  const t = useTranslations('services');

  const services = [
    {
      icon: <Search className="service-icon" />,
      title: t('seo.title'),
      description: t('seo.description'),
      features: [
        t('seo.features.0'),
        t('seo.features.1'),
        t('seo.features.2'),
        t('seo.features.3')
      ]
    },
    {
      icon: <Globe className="service-icon" />,
      title: t('googleBusiness.title'),
      description: t('googleBusiness.description'),
      features: [
        t('googleBusiness.features.0'),
        t('googleBusiness.features.1'),
        t('googleBusiness.features.2'),
        t('googleBusiness.features.3')
      ]
    },
    {
      icon: <Smartphone className="service-icon" />,
      title: t('webDev.title'),
      description: t('webDev.description'),
      features: [
        t('webDev.features.0'),
        t('webDev.features.1'),
        t('webDev.features.2'),
        t('webDev.features.3')
      ]
    },
    {
      icon: <ShoppingCart className="service-icon" />,
      title: t('erp.title'),
      description: t('erp.description'),
      features: [
        t('erp.features.0'),
        t('erp.features.1'),
        t('erp.features.2'),
        t('erp.features.3')
      ]
    }
  ];
  return (
    <section id="services" className="services-section">
      <div className="container">
        <div className="section-header">
          <h2 className="section-title">{t('title')}</h2>
          <p className="section-description">
            {t('description')}
          </p>
        </div>

        <div className="services-grid">
          {services.map((service, index) => (
            <div key={index} className="service-card">
              <div className="service-icon-wrapper">
                {service.icon}
              </div>
              <h3 className="service-title">{service.title}</h3>
              <p className="service-description">{service.description}</p>
              <ul className="service-features">
                {service.features.map((feature, i) => (
                  <li key={i} className="service-feature">
                    <CheckCircle size={16} className="feature-check" />
                    {feature}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
